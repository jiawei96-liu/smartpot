package com.alexios.florid;

import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Main6Activity extends AppCompatActivity {

    Intent from;
    BluetoothDevice mDevice;
    int []Datas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        //this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //限制为竖屏

        from = getIntent();
        mDevice = from.getParcelableExtra("bluetooth_device");  //获取蓝牙设备对象
        Datas = from.getIntArrayExtra("plant_datas");
    }

    public void goBack(View v)
    {
        Intent it = new Intent(this, Main3Activity.class);
        it.putExtra("bluetooth_device",mDevice);
        startActivity(it);
    }
}
